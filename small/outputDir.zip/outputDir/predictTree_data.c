/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: predictTree_data.c
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 29-Sep-2024 13:47:39
 */

/* Include Files */
#include "predictTree_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_outputFileName = false;

/*
 * File trailer for predictTree_data.c
 *
 * [EOF]
 */
