/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: predictTree.c
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 29-Sep-2024 13:47:39
 */

/* Include Files */
#include "predictTree.h"
#include "ClassificationTree.h"
#include "prctile.h"
#include "predictTree_data.h"
#include "predictTree_initialize.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Type Definitions */
#ifndef typedef_ClassificationTree
#define typedef_ClassificationTree
typedef struct {
  float CutPredictorIndex[69];
  float Children[138];
  float CutPoint[69];
  float PruneList[69];
  boolean_T NanCutPoints[69];
  float Cost[9];
  float ClassProbability[207];
} ClassificationTree;
#endif /* typedef_ClassificationTree */

/* Variable Definitions */
static boolean_T treeModel_not_empty;

/* Function Declarations */
static float rt_roundf_snf(float u);

/* Function Definitions */
/*
 * Arguments    : float u
 * Return Type  : float
 */
static float rt_roundf_snf(float u)
{
  float y;
  if ((float)fabs(u) < 8.388608E+6F) {
    if (u >= 0.5F) {
      y = (float)floor(u + 0.5F);
    } else if (u > -0.5F) {
      y = u * 0.0F;
    } else {
      y = (float)ceil(u - 0.5F);
    }
  } else {
    y = u;
  }
  return y;
}

/*
 * 加载预训练的决策树模型
 *
 * Arguments    : const double XTest[160]
 * Return Type  : float
 */
float predictTree(const double XTest[160])
{
  static ClassificationTree treeModel;
  static const float fv1[207] = {0.287053436F,   0.361884624F,   0.138372302F,
                                 0.202738047F,   0.742337525F,   0.0660923198F,
                                 0.604244947F,   0.168301404F,   0.362839878F,
                                 0.0767121762F,  0.870539904F,   0.0703732818F,
                                 0.0110650435F,  0.00834723562F, 0.978010237F,
                                 0.105138011F,   0.773808241F,   0.927521467F,
                                 0.0508654416F,  0.0F,           0.149732396F,
                                 0.0155763486F,  0.921702445F,   0.0406600088F,
                                 0.850439608F,   0.0316455774F,  0.0F,
                                 0.0406039432F,  0.117341951F,   0.0745763257F,
                                 0.987564683F,   0.0138888853F,  0.996838748F,
                                 0.00945060235F, 0.503225803F,   0.0F,
                                 1.0F,           0.970554471F,   0.0F,
                                 0.0223150756F,  0.994082868F,   0.0F,
                                 0.966666639F,   0.00158479158F, 0.115326121F,
                                 0.0468332134F,  0.870114326F,   0.0F,
                                 0.21153836F,    0.0F,           1.0F,
                                 0.984664857F,   0.0F,           0.0180078689F,
                                 0.149825945F,   0.926829338F,   0.0F,
                                 0.0186246559F,  0.99626869F,    0.0F,
                                 1.0F,           0.991575062F,   0.0277777892F,
                                 0.0F,           0.0F,           0.0109559288F,
                                 0.616161764F,   0.0F,           0.5F,
                                 0.340384305F,   0.44501555F,    0.132494956F,
                                 0.573731482F,   0.137311697F,   0.108821861F,
                                 0.285072565F,   0.691210687F,   0.0275356714F,
                                 0.487671494F,   0.069831118F,   0.0405669399F,
                                 0.986168683F,   0.736227393F,   0.00209425716F,
                                 0.756525397F,   0.0650798455F,  0.00195887871F,
                                 0.0416663662F,  1.0F,           0.0F,
                                 0.947040319F,   0.0173373353F,  0.0375322886F,
                                 0.120234825F,   0.0F,           1.0F,
                                 0.308694154F,   0.841214F,      0.27796647F,
                                 0.0F,           0.0F,           0.00210749893F,
                                 0.0F,           0.496774167F,   0.0F,
                                 0.0F,           0.0180599447F,  0.00370371551F,
                                 0.0381406F,     0.00591716496F, 1.0F,
                                 0.0F,           0.018225098F,   0.864946961F,
                                 0.907840848F,   0.129885629F,   0.0F,
                                 0.788461626F,   1.0F,           0.0F,
                                 0.0107545126F,  0.520548F,      0.0163601022F,
                                 0.682926476F,   0.0121951187F,  0.986135185F,
                                 0.934702694F,   0.00373135507F, 1.0F,
                                 0.0F,           0.00381132052F, 0.972222209F,
                                 1.0F,           0.0F,           0.0120277051F,
                                 0.383838266F,   0.975124359F,   0.0F,
                                 0.372562259F,   0.193099707F,   0.729132771F,
                                 0.223530456F,   0.120350793F,   0.825085878F,
                                 0.11068251F,    0.140487894F,   0.609624505F,
                                 0.435616344F,   0.0596290082F,  0.889059782F,
                                 0.00276626088F, 0.255425364F,   0.0198954418F,
                                 0.138336584F,   0.161111936F,   0.0705196559F,
                                 0.90746814F,    0.0F,           0.850267589F,
                                 0.037383236F,   0.0609602183F,  0.921807647F,
                                 0.0293255709F,  0.968354464F,   0.0F,
                                 0.65070194F,    0.0414440259F,  0.647457182F,
                                 0.0124353357F,  0.986111104F,   0.00105374947F,
                                 0.990549386F,   0.0F,           1.0F,
                                 0.0F,           0.0113856141F,  0.996296287F,
                                 0.93954432F,    0.0F,           0.0F,
                                 0.0333334059F,  0.980190098F,   0.0197268296F,
                                 0.0453259274F,  0.0F,           1.0F,
                                 0.0F,           0.0F,           0.0F,
                                 0.00458062394F, 0.479452F,      0.965632F,
                                 0.167247579F,   0.0609755889F,  0.0138647957F,
                                 0.0466725975F,  0.0F,           0.0F,
                                 0.0F,           0.00461370312F, 0.0F,
                                 0.0F,           1.0F,           0.97701633F,
                                 0.0F,           0.0248756632F,  0.5F};
  static const float fv[69] = {
      26.5F,  214.5F, 16.5F,  240.5F, 6.5F,   253.5F, 132.5F, 192.5F, 1.5F,
      92.0F,  7.5F,   109.5F, 0.0F,   23.0F,  0.0F,   23.5F,  39.5F,  28.0F,
      31.5F,  0.0F,   98.0F,  0.0F,   178.5F, 248.0F, 5.0F,   0.0F,   0.0F,
      4.5F,   210.5F, 10.0F,  0.0F,   0.0F,   0.0F,   0.0F,   3.0F,   0.0F,
      0.0F,   180.0F, 0.0F,   254.0F, 0.0F,   0.0F,   0.0F,   0.0F,   86.5F,
      224.0F, 113.5F, 0.0F,   0.0F,   0.0F,   0.0F,   203.5F, 2.5F,   112.5F,
      9.5F,   0.0F,   0.0F,   0.0F,   0.0F,   0.0F,   0.0F,   0.0F,   0.0F,
      0.0F,   0.0F,   0.0F,   0.0F,   0.0F,   0.0F};
  static const signed char iv[138] = {
      2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
      20, 21, 22, 23, 24, 25, 0,  0,  26, 27, 0,  0,  28, 29, 30, 31, 32, 33,
      34, 35, 0,  0,  36, 37, 0,  0,  38, 39, 40, 41, 42, 43, 0,  0,  0,  0,
      44, 45, 46, 47, 48, 49, 0,  0,  0,  0,  0,  0,  0,  0,  50, 51, 0,  0,
      0,  0,  52, 53, 0,  0,  54, 55, 0,  0,  0,  0,  0,  0,  0,  0,  56, 57,
      58, 59, 60, 61, 0,  0,  0,  0,  0,  0,  0,  0,  62, 63, 64, 65, 66, 67,
      68, 69, 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
      0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0};
  static const signed char iv1[69] = {
      33, 32, 28, 31, 23, 27, 22, 30, 29, 23, 21, 20, 0, 15, 0, 26, 17, 7,
      10, 0,  12, 0,  19, 16, 4,  0,  0,  24, 25, 11, 0, 0,  0, 0,  9,  0,
      0,  3,  0,  14, 0,  0,  0,  0,  8,  18, 13, 0,  0, 0,  0, 1,  2,  6,
      5,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 0,  0};
  static const unsigned char uv[69] = {
      103U, 66U, 147U, 77U,  44U,  17U, 65U,  33U, 41U, 16U,  36U,  39U,
      0U,   29U, 0U,   85U,  36U,  27U, 108U, 0U,  18U, 0U,   135U, 131U,
      14U,  0U,  0U,   140U, 133U, 12U, 0U,   0U,  0U,  0U,   34U,  0U,
      0U,   5U,  0U,   26U,  0U,   0U,  0U,   0U,  7U,  139U, 56U,  0U,
      0U,   0U,  0U,   106U, 11U,  49U, 70U,  0U,  0U,  0U,   0U,   0U,
      0U,   0U,  0U,   0U,   0U,   0U,  0U,   0U,  0U};
  static const signed char iv2[9] = {0, 1, 1, 1, 0, 1, 1, 1, 0};
  static const boolean_T bv[69] = {
      false, false, false, false, false, false, false, false, false, false,
      false, false, true,  false, true,  false, false, false, false, true,
      false, true,  false, false, false, true,  true,  false, false, false,
      true,  true,  true,  true,  false, true,  true,  false, true,  false,
      true,  true,  true,  true,  false, false, false, true,  true,  true,
      true,  false, false, false, false, true,  true,  true,  true,  true,
      true,  true,  true,  true,  true,  true,  true,  true,  true};
  float current_matrix[160];
  float f;
  float lower_percentile;
  float y;
  int i;
  if (!isInitialized_outputFileName) {
    predictTree_initialize();
  }
  if (!treeModel_not_empty) {
    for (i = 0; i < 69; i++) {
      treeModel.CutPredictorIndex[i] = uv[i];
    }
    for (i = 0; i < 138; i++) {
      treeModel.Children[i] = iv[i];
    }
    for (i = 0; i < 69; i++) {
      treeModel.CutPoint[i] = fv[i];
      treeModel.PruneList[i] = iv1[i];
      treeModel.NanCutPoints[i] = bv[i];
    }
    for (i = 0; i < 9; i++) {
      treeModel.Cost[i] = iv2[i];
    }
    for (i = 0; i < 207; i++) {
      treeModel.ClassProbability[i] = fv1[i];
    }
    treeModel_not_empty = true;
  }
  /*  归一化输入数据 */
  /*  使用单精度浮点数 */
  for (i = 0; i < 160; i++) {
    current_matrix[i] = (float)XTest[i];
  }
  /*  转换为单精度 */
  lower_percentile = percentile_vector(current_matrix, 5.0);
  /*  归一化到 0-255 范围并取整 */
  y = percentile_vector(current_matrix, 95.0) - lower_percentile;
  for (i = 0; i < 160; i++) {
    f = (current_matrix[i] - lower_percentile) / y * 255.0F;
    if ((f >= 255.0F) || rtIsNaNF(f)) {
      f = 255.0F;
    }
    if (f <= 0.0F) {
      f = 0.0F;
    }
    current_matrix[i] = rt_roundf_snf(f);
  }
  /*  重塑输入数据 */
  /*  使用归一化后的数据进行预测 */
  return ClassificationTree_predict(
      treeModel.CutPredictorIndex, treeModel.Children, treeModel.CutPoint,
      treeModel.PruneList, treeModel.NanCutPoints, treeModel.Cost,
      treeModel.ClassProbability, current_matrix);
}

/*
 * 加载预训练的决策树模型
 *
 * Arguments    : void
 * Return Type  : void
 */
void predictTree_init(void)
{
  treeModel_not_empty = false;
}

/*
 * File trailer for predictTree.c
 *
 * [EOF]
 */
