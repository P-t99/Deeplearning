/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_predictTree_info.c
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 29-Sep-2024 13:47:39
 */

/* Include Files */
#include "_coder_predictTree_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *c_emlrtMexFcnResolvedFunctionsI(void);

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
static const mxArray *c_emlrtMexFcnResolvedFunctionsI(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[5] = {
      "789ce554c14ac34010dd8882206af12078172f4210112de2ad45add05268444bb7d06d32"
      "6da3bbd9b0bb95f807defc058f7e82f81ddefc03ff41b04d9b340d84"
      "140b11752eb3c39bddf776766790562a6b08a13534b2e795915f1dc7b9b15f40d316c7b5"
      "589e369d8e96d0e2d4be007f1c7b933b0a3c350a1cc220dc6971663b",
      "c451c6bd0b4880e4f40e2c1fe9d8140c9b412d1a5486113b8d4061308486eb420fccdb5a"
      "9f21d1931385341a84f56825dc7731a51e718bd7239ef75ff89ebec9"
      "179c7f92c217e08dcb66f1180b70b9b41517f7d802702910e1d84e174b4628c59dc1bfa2"
      "55d177c0320440995b40754654546f2b41cffa8c7ae37e92bfecfbfd",
      "8d772d4bbec6d687c8922fb09fe2f312ce9bf5bf6d26f0e56278bd5e2687c5bdf3eba33c"
      "b9b93b53dd2bcf2e9e4e74545378d274a08438abf35f12f6cf5ac7cb"
      "84f37331bc512a34b7073d48495b70aeb6b1e29cb6b987a5224a629312290574f1ee6415"
      "76f5ae39e860810b9cb9c4545501966d0e7a5f67917b3ccc798f9d94",
      "7b0478204f0fd4e9beb8beb2a9d40d411cd9e182fddc1c9ef73d6b297c01de2855e67c4f"
      "bf64382c99ff9ad9cd93e3d7b74ce733c29f3453beb1fdf5f97c410c"
      "a34fac2bd1ae28f7a09ef7f6f6b928fcfef9fc05f827b7aa",
      ""};
  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 3008U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[9] = {"Version",
                                    "ResolvedFunctions",
                                    "Checksum",
                                    "EntryPoints",
                                    "CoverageInfo",
                                    "IsPolymorphic",
                                    "PropertyList",
                                    "UUID",
                                    "ClassEntryPointIsHandle"};
  const char_T *epFieldName[8] = {
      "Name",     "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "FullPath", "TimeStamp",      "Constructor",     "Visible"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 8, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("predictTree"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath",
                emlrtMxCreateString(
                    "D:\\repository\\deeplearning\\small\\predictTree.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(739524.5730092593));
  emlrtSetField(xEntryPoints, 0, "Constructor",
                emlrtMxCreateLogicalScalar(false));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 9, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("23.2.0.2515942 (R2023b) Update 7"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("BIEFrZwTosx4Xo6YUvXUx"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_predictTree_info.c
 *
 * [EOF]
 */
