/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: predictTree_data.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 29-Sep-2024 13:47:39
 */

#ifndef PREDICTTREE_DATA_H
#define PREDICTTREE_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern boolean_T isInitialized_outputFileName;

#endif
/*
 * File trailer for predictTree_data.h
 *
 * [EOF]
 */
