/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ClassificationTree.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 29-Sep-2024 13:47:39
 */

#ifndef CLASSIFICATIONTREE_H
#define CLASSIFICATIONTREE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
float ClassificationTree_predict(
    const float obj_CutPredictorIndex[69], const float obj_Children[138],
    const float obj_CutPoint[69], const float obj_PruneList[69],
    const boolean_T obj_NanCutPoints[69], const float obj_Cost[9],
    const float obj_ClassProbability[207], const float Xin[160]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for ClassificationTree.h
 *
 * [EOF]
 */
